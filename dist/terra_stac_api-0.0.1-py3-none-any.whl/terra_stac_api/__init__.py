import importlib.metadata

__name__ = "terra-stac-api"
__version__ = importlib.metadata.version(__name__)
